# DAC_Phase3
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
data=pd.read_csv("C:\\Users\harsh\OneDrive\Desktop\country_vaccinations.csv\country_vaccinations.csv")
data.head()
